//
//  CinemaViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "CinemaViewController.h"
#import "District.h"
#import "Cinema.h"
#import "CinemaCell.h"

@interface CinemaViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_districtData;
    
    UITableView *_tabView;
    
    BOOL _isSelect[100];
    
}
@end

@implementation CinemaViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"影院";
    [self _loadData];
    
    NSLog(@"%@",_districtData);
    [self _creatViews];
    
    
}
-(void)_loadData{
    
    NSDictionary *dic1 = [MovieJSON readJSONFile:@"district_list"];
    NSArray *array1 = dic1[@"districtList"];
    _districtData = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in array1) {
        District *district = [[District alloc] initContentWithDic:dic];
        [_districtData addObject:district];
    }
    
    NSDictionary *dic2 = [MovieJSON readJSONFile:@"cinema_list"];
    NSArray *array2 = dic2[@"cinemaList"];
    for (NSDictionary *dic in array2) {
        Cinema *cinema = [[Cinema alloc] initContentWithDic:dic];
        for (District *dis in _districtData) {
            if ([dis.districtID isEqualToString:cinema.districtId]) {
                [dis.cinemas addObject:cinema];
                break;
            }
        }
        
    }
    
    
    
    
    
}

-(void)_creatViews{
    _tabView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    
    _tabView.backgroundColor = [UIColor blackColor];
    _tabView.delegate = self;
    _tabView.dataSource = self;
    [self.view addSubview:_tabView];
    
    
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    
    //NSLog(@" a = %ld",_districtData.count);
    return _districtData.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (_isSelect[section]) {
        District *dis = _districtData[section];
        return dis.cinemas.count;
    }
    else
    {
        return 0;
    }
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CinemaCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CinemaCell"];
    
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"CinemaCell" owner:nil options:nil] lastObject ];
    }
    District *dis = _districtData[indexPath.section];
    cell.cinema = dis.cinemas[indexPath.row];
    UIImageView *imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"movieTimeCellBackground"]];
    cell.backgroundView = imageView;
    
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 80;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake(0, 0, self.view.bounds.size.width, 30);
    [btn setBackgroundImage:[UIImage imageNamed:@"hotMovieBottomImage"] forState:UIControlStateNormal];
    
    District *dis = _districtData[section];
    NSString *str = dis.name;
    
    [btn setTitle:str forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(change:) forControlEvents:UIControlEventTouchUpInside];
    btn.tag = section + 100;
    return btn;
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
    
}
-(void)change:(UIButton *)sender{
    NSInteger i = sender.tag - 100;
    _isSelect[i] = !_isSelect[i];
    
    [_tabView reloadSections:[NSIndexSet indexSetWithIndex:i] withRowAnimation:UITableViewRowAnimationAutomatic];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
