//
//  CinemaCell.h
//  TimeMovie
//
//  Created by apple on 15/8/28.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Cinema.h"

@interface CinemaCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cinemaNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;

@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;
@property (weak, nonatomic) IBOutlet UIImageView *seatImageView;

@property (weak, nonatomic) IBOutlet UIImageView *couponImageView;

@property (weak, nonatomic) IBOutlet UIImageView *groupBuyImageView;
@property (weak, nonatomic) IBOutlet UIImageView *imaxImageView;

@property(nonatomic,strong)Cinema *cinema;

@end
