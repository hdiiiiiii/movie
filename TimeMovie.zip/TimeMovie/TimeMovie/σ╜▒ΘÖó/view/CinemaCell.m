//
//  CinemaCell.m
//  TimeMovie
//
//  Created by apple on 15/8/28.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "CinemaCell.h"

@implementation CinemaCell

//@property (weak, nonatomic) IBOutlet UILabel *cinemaNameLabel;
//@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;
//
//@property (weak, nonatomic) IBOutlet UILabel *addressLabel;
//@property (weak, nonatomic) IBOutlet UILabel *priceLabel;
//@property (weak, nonatomic) IBOutlet UILabel *distanceLabel;
//@property (weak, nonatomic) IBOutlet UIImageView *seatImageView;
//
//@property (weak, nonatomic) IBOutlet UIImageView *couponImageView;
//
//@property (weak, nonatomic) IBOutlet UIImageView *groupBuyImageView;

-(void)setCinema:(Cinema *)cinema{
    _cinema = cinema;
    self.cinemaNameLabel.text = _cinema.name;
    self.ratingLabel.text = _cinema.grade;
    self.addressLabel.text = _cinema.address;
    
    NSString *str = [NSString stringWithFormat:@"$%@",_cinema.lowPrice];
    
    self.priceLabel.text = str;
    if ([_cinema.isSeatSupport isEqualToString:@"1"]) {
        self.seatImageView.image = [UIImage imageNamed:@"cinemaSeatMark"];
    }
    if ([_cinema.isCouponSupport isEqualToString:@"1"]) {
        self.couponImageView.image = [UIImage imageNamed:@"cinemaCouponMark"];
    }
    if ([_cinema.isGroupBuySupport isEqualToString:@"1"]) {
        self.groupBuyImageView.image = [UIImage imageNamed:@"cinemaGrouponMark"];
    }
    if ([_cinema.isImaxSupport isEqualToString:@"1"]) {
        self.imaxImageView.image = [UIImage imageNamed:@"imaxMark@2x"];
    }
    
    
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
