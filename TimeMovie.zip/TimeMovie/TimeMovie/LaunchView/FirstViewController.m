//
//  FirstViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/31.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "FirstViewController.h"

@interface FirstViewController ()<UIScrollViewDelegate>

{
    UIImageView *_PageimageView;
}
@end

@implementation FirstViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor blackColor];
    
    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:self.view.bounds];
    scrollView.contentSize = CGSizeMake(kScreenWidth *5, kScreenHeight);
    scrollView.delegate = self;
    scrollView.pagingEnabled = YES;
    scrollView.showsHorizontalScrollIndicator = NO;
    [self.view addSubview:scrollView];
    
    for (int i = 1; i < 6; i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((i-1)*kScreenWidth, 0, kScreenWidth, kScreenHeight)];
        NSString *imageName = [NSString stringWithFormat:@"guide%d",i];
        imageView.image = [UIImage imageNamed:imageName];
        [scrollView addSubview:imageView];
        
    }
    //添加按钮
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    btn.frame = CGRectMake((kScreenWidth*4+kScreenWidth/2-75), kScreenHeight*0.8, 150, 40);
    [btn setBackgroundImage:[UIImage imageNamed:@"nav_bg_all"] forState:UIControlStateNormal];
    [btn setTitle:@"欢迎来到电影世界" forState:UIControlStateNormal];
    [scrollView addSubview:btn];
    [btn addTarget:self
            action:@selector(jumpToMainView)
  forControlEvents:UIControlEventTouchUpInside];
    
    //分页视图
    _PageimageView = [[UIImageView alloc] initWithFrame:CGRectMake((kScreenWidth-87)/2, kScreenHeight*0.9, 87, 13)];
    NSString *imageName = [NSString stringWithFormat:@"guideProgress%@",@"1"];
    _PageimageView.image = [UIImage imageNamed:imageName];
    [self.view addSubview:_PageimageView];
    
    
}

#pragma mark -计算页数
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    
    [_PageimageView removeFromSuperview];
    //获取最终的偏移量
    CGFloat offX = scrollView.contentOffset.x;
    //计算当前的页数
    NSInteger index =  offX / kScreenWidth;
    NSString *imageName = [NSString stringWithFormat:@"guideProgress%ld",index+1];
    _PageimageView.image = [UIImage imageNamed:imageName];
    [self.view addSubview:_PageimageView];
    
    
}
#pragma mark -按钮方法

-(void)jumpToMainView{
    //从故事板读取
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    UIViewController *vc = [story instantiateInitialViewController];
    
    self.view.window.rootViewController = vc;
    
    vc.view.transform = CGAffineTransformMakeScale(.1, .1);
    [UIView animateWithDuration:.3 animations:^{
        vc.view.transform = CGAffineTransformIdentity;
        
    }];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setBool:@YES forKey:@"first"];
    
}

#pragma mark -隐藏显示状态栏
-(void)viewWillAppear:(BOOL)animated{
    UIApplication *app  = [UIApplication sharedApplication];
    [app setStatusBarHidden:YES];
    
}
-(void)viewDidDisappear:(BOOL)animated{
    UIApplication *app  = [UIApplication sharedApplication];
    [app setStatusBarHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
