//
//  LaunchViewController.h
//  TimeMovie
//
//  Created by apple on 15/8/31.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "ViewController.h"

@interface LaunchViewController : ViewController

@end
