//
//  LaunchViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/31.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "LaunchViewController.h"

@interface LaunchViewController ()

@end

@implementation LaunchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [NSTimer scheduledTimerWithTimeInterval:.1
                                     target:self
                                   selector:@selector(showImageView:)
                                   userInfo:nil
                                    repeats:YES];
    self.view.backgroundColor = [UIColor blackColor];
    
}

-(void)viewWillAppear:(BOOL)animated{
    UIApplication *app = [UIApplication sharedApplication];
    [app setStatusBarHidden:YES];
    
}
-(void)viewWillDisappear:(BOOL)animated{
    UIApplication *app = [UIApplication sharedApplication];
    [app setStatusBarHidden:NO];
    
}

-(void)showImageView:(NSTimer *)timer{
    static NSInteger i = 1;
    UIImageView *imageView = (UIImageView *)[self.view viewWithTag:i];
    imageView.hidden = NO;
    
    i++;
    if (i == 25) {
        [timer invalidate];
        
        
        [self performSelector:@selector(jumpToMainView) withObject:nil afterDelay:.3];
        
    }
    
    
}
-(void)jumpToMainView{
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    
    UIViewController *vc = [story instantiateInitialViewController];
    
    self.view.window.rootViewController = vc;
    vc.view.transform = CGAffineTransformMakeScale(.1, .1);
    [UIView animateWithDuration:.3 animations:^{
        vc.view.transform = CGAffineTransformIdentity;
        
    }];
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    [userDefaults setBool:nil forKey:@"first"];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
