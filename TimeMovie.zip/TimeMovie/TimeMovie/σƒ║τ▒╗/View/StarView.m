//
//  StarView.m
//  StarView
//
//  Created by apple on 15/8/22.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "StarView.h"

@interface StarView()
{
    UIView *_yellowView;
    UIView *_grayView;
}

@end

@implementation StarView

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        [self _createStarView];
    }
    
    return self;
    
}


-(void)_createStarView{
    _grayView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 17.5*5, 17)];
    _grayView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"gray"]];
    CGAffineTransform transform = CGAffineTransformMakeScale(self.frame.size.width/17.5/5, self.frame.size.height/17);
    _grayView.transform = transform;
    [self addSubview:_grayView];
    
    _yellowView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 17.5*5, 17)];
    _yellowView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"yellow"]];
    _yellowView.transform = transform;
    [self addSubview: _yellowView];
    
    CGPoint selfCenterPoint = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2);
    _yellowView.center = selfCenterPoint;
    _grayView.center = selfCenterPoint;
    
    
}
-(void)setRating:(CGFloat)rating{
    if (rating>=0&&rating<=10) {
        _rating = rating;
        _yellowView.width = _grayView.width*rating/10;
        
    }
    
    
}

@end
