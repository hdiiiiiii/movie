//
//  BaseTabBarController.m
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "BaseTabBarController.h"
#import "TabbarButton.h"
#import "TabBarButton.h"



@interface BaseTabBarController ()
{
    UIView *_customTabbar;
    UIImageView *_selectedImageView;
}
@end

@implementation BaseTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self _creatView];
    
    
}

-(void)_creatView{
    self.tabBar.hidden = YES;
    //自定义标签栏
    _customTabbar = [[UIView alloc] initWithFrame:CGRectMake(0, kScreenHeight - 49, kScreenWidth, 49)];
    _customTabbar.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"tab_bg_all"]];
    [self.view addSubview:_customTabbar];
    //定义选择视图
    CGFloat buttonWidth = kScreenWidth/self.viewControllers.count;
    _selectedImageView = [[UIImageView alloc] initWithFrame:CGRectMake(5.5, 3, buttonWidth-10, 44)];
    _selectedImageView.image = [UIImage imageNamed:@"selectTabbar_bg_all1"];
    [_customTabbar addSubview:_selectedImageView];
    //自定义标签栏上的按钮
    NSArray *title = @[@"电影",@"新闻",@"Top",@"影院",@"更多"];
    NSArray *imageNames = @[@"movie_home",@"msg_new",@"start_top250",@"icon_cinema",@"more_select_setting"];
    for (int i = 0; i < self.viewControllers.count; i++) {
        TabBarButton *tabbarBtn = [[TabBarButton alloc]initWithTitle:title[i] imageName:imageNames[i] frame:CGRectMake(buttonWidth * i , 0, buttonWidth, 49)];
        [_customTabbar addSubview:tabbarBtn];
        
        [tabbarBtn addTarget:self
                      action:@selector(buttonActiom:)
            forControlEvents:UIControlEventTouchUpInside];
        tabbarBtn.tag = i + 100;
        
    }
    
    
//    for (int i = 0; i< self.viewControllers.count; i++) {
//        TabBarButton *tabbarBtn = [[TabBarButton alloc] initWithTitle:title[i] imageName:imageNames[i] frame:CGRectMake(buttonWidth * i , 0, buttonWidth, 49)];
//        [tabbarBtn addTarget:self
//                      action:@selector(buttonActiom:)
//            forControlEvents:UIControlEventTouchUpInside];
//        tabbarBtn.tag = i + 100;
//    }
    
    
}


-(void)buttonActiom:(UIButton *)sender{
    NSInteger i =sender.tag  - 100;
    self.selectedIndex = i;
    [UIView animateWithDuration:.2 animations:^{
        
        _selectedImageView.frame = CGRectMake(i*sender.frame.size.width+5, 3, sender.frame.size.width-10, 44);
   
    }];
    
    
    
}

-(void)setTabBarHidden:(BOOL)isHidden{
    _customTabbar.hidden = isHidden;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
