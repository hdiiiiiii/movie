//
//  BaseViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "BaseViewController.h"
#import "BaseTabBarController.h"

@interface BaseViewController ()
{
    UILabel *_titleLabel;
    BOOL _isHiddenTabbr;
}
@end

@implementation BaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _titleLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 180, 40)];
    _titleLabel.textColor = [UIColor whiteColor];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    _titleLabel.font = [UIFont systemFontOfSize:20 weight:.8];
    _titleLabel.text = self.title;
    //将自定义主题添加到状态栏
    self.navigationItem.titleView = _titleLabel;
    
    self.view.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    
    
    
}

//setTitle
-(void)setTitle:(NSString *)title{
    [super setTitle:title];
    
    _titleLabel.text = title;
}



#pragma mark -隐藏标签栏
-(void)viewWillAppear:(BOOL)animated{
    if (_isHiddenTabbr) {
        BaseTabBarController *tab = (BaseTabBarController *)self.tabBarController;
        [tab setTabBarHidden:YES];
    }
    else{
        
        BaseTabBarController *tab = (BaseTabBarController *)self.tabBarController;
        [tab setTabBarHidden:NO];
    
    }
    
    
}

-(void)viewWillDisappear:(BOOL)animated{
    
    BaseTabBarController *tab = (BaseTabBarController *)self.tabBarController;
    [tab setTabBarHidden:NO];
    
}

-(void)setHidesBottomBarWhenPushed:(BOOL)hidesBottomBarWhenPushed{
    _isHiddenTabbr = hidesBottomBarWhenPushed;
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
