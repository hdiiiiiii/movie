//
//  MovieJSON.h
//  TimeMovie
//
//  Created by apple on 15/8/22.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieJSON : NSObject

+(id)readJSONFile:(NSString *)fileName;

@end
