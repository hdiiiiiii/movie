//
//  SmallPostCollectionView.m
//  TimeMovie
//
//  Created by apple on 15/8/26.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "SmallPostCollectionView.h"
#import "SmallPostCell.h"
#import "PostCollectionView.h"

@interface SmallPostCollectionView ()<UICollectionViewDataSource,UICollectionViewDelegate>

@end


@implementation SmallPostCollectionView

-(instancetype)initWithFrame:(CGRect)frame{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(frame.size.width/5, frame.size.height*0.65);
    layout.sectionInset = UIEdgeInsetsMake(0, frame.size.width/2-frame.size.width/10+2, 0, frame.size.width/2-frame.size.width/10-2);
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    layout.minimumInteritemSpacing = 6;
    
    self = [super initWithFrame:frame collectionViewLayout:layout];
    if (self) {
        self.dataSource = self;
        self.delegate = self;
        self.showsHorizontalScrollIndicator = NO;
        
        UINib *nib = [UINib nibWithNibName:@"SmallPostCell" bundle:[NSBundle mainBundle]];
        [self registerNib:nib forCellWithReuseIdentifier:@"smallPostCell"];
        

        
    }
    
    
    
    return self;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _imageData.count;
}


- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    SmallPostCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"smallPostCell" forIndexPath:indexPath];
    cell.movie = _imageData[indexPath.item];
    cell.backgroundColor = [UIColor blueColor];
    return cell;
    
}

#pragma mark -实现分业效果
-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView
                    withVelocity:(CGPoint)velocity
             targetContentOffset:(inout CGPoint *)
targetContentOffset{
    
    CGFloat xOffset = targetContentOffset->x;
    xOffset -= scrollView.width/5/2;
    NSInteger index = xOffset/(scrollView.width/5+6);
    
    //NSLog(@"%ld",index);
    if (xOffset>0) {
        index +=1;
    }
    if (index <10) {
        self.index = index;
    }
    
    xOffset = index * (scrollView.width /5+10);
    targetContentOffset->x = xOffset;
    
    
}

-(void)collectionView:(UICollectionView *)collectionView
didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    [collectionView scrollToItemAtIndexPath:indexPath
                           atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                   animated:YES];
    self.index = indexPath.item;
    
    
}



@end
