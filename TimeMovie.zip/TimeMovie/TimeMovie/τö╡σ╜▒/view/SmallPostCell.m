//
//  SmallPostCell.m
//  TimeMovie
//
//  Created by apple on 15/8/26.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "SmallPostCell.h"

@interface SmallPostCell()

@property (weak, nonatomic) IBOutlet UIImageView *smallImageView;

@end

@implementation SmallPostCell


-(void)setMovie:(Movie *)movie{
    _movie = movie;
    NSURL *url = [NSURL URLWithString:_movie.images[@"small"]];
    [_smallImageView sd_setImageWithURL:url placeholderImage:[UIImage imageNamed:@"icon"]];
    
    
}

- (void)awakeFromNib {
    // Initialization code
}

@end
