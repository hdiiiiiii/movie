//
//  PostCollectionView.m
//  TimeMovie
//
//  Created by apple on 15/8/26.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "PostCollectionView.h"
#import "PostCell.h"

@interface PostCollectionView()<UICollectionViewDataSource,UICollectionViewDelegate>

@end

@implementation PostCollectionView

-(instancetype)initWithFrame:(CGRect)frame{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(frame.size.width*0.6, frame.size.height*0.6);
    layout.sectionInset = UIEdgeInsetsMake(0, frame.size.width*0.2, 0, frame.size.width*0.2);
    layout.minimumInteritemSpacing = 10;
    layout.scrollDirection =UICollectionViewScrollDirectionHorizontal;
    
    self = [super initWithFrame:frame collectionViewLayout:layout];
    if (self) {
        self.dataSource = self;
        self.delegate = self;
        self.showsHorizontalScrollIndicator = NO;
        
        UINib *nib = [UINib nibWithNibName:@"PostCell" bundle:[NSBundle mainBundle]];
        [self registerNib:nib forCellWithReuseIdentifier:@"postCollectionCell"];
        
    }
    return self;
    
    
    
}
#pragma mark -协议方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _movieData.count;
    
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    PostCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"postCollectionCell" forIndexPath:indexPath];
    cell.movie = _movieData[indexPath.item];
    return cell;
    
}

#pragma mark -实现分业效果
-(void)scrollViewWillEndDragging:(UIScrollView *)scrollView
                    withVelocity:(CGPoint)velocity
             targetContentOffset:(inout CGPoint *)
targetContentOffset{
    
    //NSLog(@"velocity = %f",velocity.x);
    //NSLog(@"targetContentOffset = %f",targetContentOffset->x);
    
    CGFloat xOffset = targetContentOffset->x;
    xOffset -= scrollView.width*0.3;
    NSInteger index = xOffset/(scrollView.width*0.6+10);
    
    NSLog(@"%ld",index);
    if (xOffset>0) {
        index +=1;
    }
    self.index = index;
    xOffset = index * (scrollView.width * 0.6 +10);
    targetContentOffset->x = xOffset;
    
}

#pragma mark -翻转效果
-(void)collectionView:(UICollectionView *)collectionView
didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSInteger index = collectionView.contentOffset.x/(collectionView.width*0.6 +10);
    if (indexPath.item == index) {
        PostCell *cell = (PostCell *)[collectionView cellForItemAtIndexPath:indexPath];
        [cell flipCell];
    }
    else{
        
        [collectionView scrollToItemAtIndexPath:indexPath
                               atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally
                                       animated:YES];
        self.index = indexPath.item;
        
    }
    
    
}
#pragma mark -取消翻转
-(void)collectionView:(UICollectionView *)collectionView
 didEndDisplayingCell:(UICollectionViewCell *)cell
   forItemAtIndexPath:(NSIndexPath *)indexPath{
    PostCell *postCell = (PostCell *)cell;
    [postCell cancelFlip];
    
}






@end
