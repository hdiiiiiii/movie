//
//  PostCell.m
//  TimeMovie
//
//  Created by apple on 15/8/26.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "PostCell.h"
#import "StarView.h"

@interface PostCell ()
@property (weak, nonatomic) IBOutlet UIImageView *bigImageVIew;
@property (weak, nonatomic) IBOutlet UIImageView *smallImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleCLabel;
@property (weak, nonatomic) IBOutlet UILabel *titleELabel;
@property (weak, nonatomic) IBOutlet UILabel *yearLabel;
@property (weak, nonatomic) IBOutlet UIView *starview;



@end

@implementation PostCell


-(void)setMovie:(Movie *)movie{
    _movie = movie;
    NSURL *url1 = [NSURL URLWithString:movie.images[@"large"]];
    NSURL *url2 = [NSURL URLWithString:movie.images[@"medium"]];
    [_bigImageVIew sd_setImageWithURL:url1 placeholderImage:[UIImage imageNamed:@"icon"]];
    [_smallImageView sd_setImageWithURL:url2 placeholderImage:[UIImage imageNamed:@"icon"]];
    _titleCLabel.text = _movie.titleC;
    _titleELabel.text = _movie.titleE;
    _yearLabel.text = _movie.year;
    
    StarView *starView = [[StarView alloc] initWithFrame:CGRectMake(0, 0, 150, 30)];
    starView.rating = _movie.rating;
    _starview.backgroundColor = [UIColor clearColor];
    [_starview addSubview:starView];
    
    
}
#pragma mark -翻转与大图的隐藏
-(void)flipCell{
    [UIView transitionWithView:self
                      duration:.3 options:UIViewAnimationOptionTransitionFlipFromLeft
                    animations:^{
                        _bigImageVIew.hidden = !_bigImageVIew.hidden;
                    }
                    completion:nil];
}


-(void)cancelFlip{
    _bigImageVIew.hidden = NO;
    
}

- (void)awakeFromNib {
    // Initialization code
}

@end
