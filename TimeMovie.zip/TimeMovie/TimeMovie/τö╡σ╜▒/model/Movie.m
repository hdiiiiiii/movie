//
//  Movie.m
//  TimeMovie
//
//  Created by apple on 15/8/21.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "Movie.h"
#import "MyCell.h"
@implementation Movie

-(id)initWithContentsOfDictionary:(NSDictionary *)dictionary{
    if (self = [super init]) {
        
        _titleC = dictionary[@"title"];
        _titleE = dictionary[@"original_title"];
        NSDictionary *ratingDic = dictionary[@"rating"];
        NSNumber *number = ratingDic[@"average"];
        _rating = [number floatValue];
        _year = dictionary[@"year"];
        _images = dictionary[@"images"];
        
    }
    return self;
    
}
+(id)movieWithContentsOfDictionary:(NSDictionary *)dictionary{
    return [[Movie alloc]initWithContentsOfDictionary:dictionary];
}





@end
