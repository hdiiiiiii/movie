//
//  MovieViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "MovieViewController.h"
#import "Movie.h"
#import "MyCell.h"
#import "MovieJSON.h"
#import "PostCollectionView.h"
#import "SmallPostCollectionView.h"
#import "BaseTabBarController.h"

@interface MovieViewController ()
{
    UIButton *_rightButton;
    
    UITableView *_listView;
    UIView *_postView;
    PostCollectionView *_postCollectionView;
    SmallPostCollectionView *_smallPostCollectionView;
    
    NSMutableArray *_movieData;
    
    UIView *_headView;
    UIButton *_upDownBtn;
    
    UIView *_maskView;
    
    UIImageView *_lightViewRight;
    UIImageView *_lightViewLeft;
}
@end

@implementation MovieViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"电影";    
    //读取文件
    [self loadData];
    
    //创建按钮
    [self _creatButton];
    
    //创建表视图
    [self _creatView];
    //添加顶部视图
    [self _creatHeadview];
    
    [_postCollectionView
     addObserver:self forKeyPath:@"index" options:NSKeyValueObservingOptionNew context:nil];
    [_smallPostCollectionView addObserver:self forKeyPath:@"index" options:NSKeyValueObservingOptionNew context:nil];
    
    
    
}

#pragma mark -观察者方法
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    
    NSInteger index = [change[@"new"] intValue];
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:index inSection:0];
    
    if (object == _postCollectionView && _smallPostCollectionView.index != index) {
        [_smallPostCollectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        _smallPostCollectionView.index = index;
    }
    else if (object == _smallPostCollectionView && _postCollectionView.index != index){
        [_postCollectionView scrollToItemAtIndexPath:indexPath atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:YES];
        _postCollectionView.index = index;
        
    }
    
    
    
    
}
-(void)dealloc{
    [_postCollectionView removeObserver:self forKeyPath:@"index"];
    [_smallPostCollectionView removeObserver:self forKeyPath:@"index"];
    
}

#pragma mark -创建顶部视图
-(void)_creatHeadview{
    _postView.backgroundColor = [UIColor greenColor];
    
    //创建遮蔽视图
    _maskView = [[UIView alloc] initWithFrame:_postView.bounds];
    _maskView.backgroundColor = [UIColor colorWithRed:0 green:0 blue:0 alpha:.5];
    _maskView.hidden = YES;
    [_postView addSubview:_maskView];
    //单击上移
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(headViewMoveUp)];
    
    [_maskView addGestureRecognizer:tap];
    //下滑下移
    UISwipeGestureRecognizer *swipDown = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(headViewMoveDown)];
    swipDown.direction = UISwipeGestureRecognizerDirectionDown;
    [_postView addGestureRecognizer:swipDown];
    //上滑上移
    UISwipeGestureRecognizer *swipUp = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(headViewMoveUp)];
    swipUp.direction = UISwipeGestureRecognizerDirectionUp;
    [_postView addGestureRecognizer:swipUp];
    
    
    //创建顶部视图
    _headView = [[UIView alloc] initWithFrame:CGRectMake(0, 64-100, kScreenWidth, 120)];
    _headView.backgroundColor = [UIColor clearColor];
    [_postView addSubview:_headView];
    
    UIImage *indexBG = [UIImage imageNamed:@"indexBG_home"];
    //拉伸图片
    indexBG = [indexBG stretchableImageWithLeftCapWidth:0 topCapHeight:5];
    
    UIImageView *BGImageView = [[UIImageView alloc] initWithFrame:_headView.bounds];
    BGImageView.image = indexBG;
    [_headView addSubview:BGImageView];
    
    //创建顶部小滑动视图
    _smallPostCollectionView = [[SmallPostCollectionView alloc] initWithFrame:_headView.bounds];
    _smallPostCollectionView.backgroundColor = [UIColor clearColor];
    [_headView addSubview:_smallPostCollectionView];
    _smallPostCollectionView.imageData = _movieData;
    
    
    _lightViewLeft = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth/2-120, 64, 100, 204)];
    _lightViewLeft.image = [UIImage imageNamed:@"light"];
    _lightViewRight = [[UIImageView alloc] initWithFrame:CGRectMake(kScreenWidth/2+26, 64, 100, 204)];
    _lightViewRight.image = [UIImage imageNamed:@"light"];
    _lightViewRight.hidden = YES;
    _lightViewLeft.hidden = YES;
    [_postView addSubview:_lightViewRight];
    [_postView addSubview:_lightViewLeft];
    
    
    //设置按钮
    _upDownBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    _upDownBtn.frame = CGRectMake(0, 0, 26, 20);
    _upDownBtn.center = CGPointMake(kScreenWidth/2 + 3, 115);
    
    [_upDownBtn setImage:[UIImage imageNamed:@"down_home"] forState:UIControlStateNormal];
    [_upDownBtn setImage:[UIImage imageNamed:@"up_home"] forState:UIControlStateSelected];
    
    [_upDownBtn addTarget:self
                   action:@selector(upDownBtnAction:)
         forControlEvents:UIControlEventTouchUpInside];
    
    [_headView addSubview:_upDownBtn];
    
    
}
#pragma mark -按钮方法
-(void)upDownBtnAction:(UIButton *)sender{
    sender.selected = !sender.selected;
    if (sender.selected) {
        [self headViewMoveDown];
    }
    else
    {
        [self headViewMoveUp];
    }
    
    
}
#pragma mark -上移
-(void)headViewMoveUp{
    
    [UIView animateWithDuration:.3 animations:^{
        
        _headView.top = -32;
        _maskView.hidden = YES;
        _upDownBtn.selected = NO;
        _lightViewLeft.hidden = YES;
        _lightViewRight.hidden = YES;
        
    }];

    
}
#pragma mark -下移
-(void)headViewMoveDown{
    [UIView animateWithDuration:.3 animations:^{
        
        _headView.top = 64;
        _maskView.hidden = NO;
        _upDownBtn.selected = YES;
        _lightViewLeft.hidden = NO;
        _lightViewRight.hidden = NO;
    }];
}


#pragma mark -读取文件
-(void)loadData{

    NSDictionary *dic =[MovieJSON readJSONFile:@"us_box"];
    
    //数据处理和存储
    NSArray *subjects = dic[@"subjects"];
    _movieData = [[NSMutableArray alloc] init];
    for (NSDictionary *dictionary in subjects) {
        Movie *movie = [Movie movieWithContentsOfDictionary:dictionary[@"subject"]];
        [_movieData addObject:movie];
    }
    
    
}


#pragma mark -创建表视图
-(void)_creatView{
    _listView = [[UITableView alloc] initWithFrame:self.view.bounds];
    _listView.delegate = self;
    _listView.dataSource = self;
    [self.view addSubview:_listView];
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.image = [UIImage imageNamed:@"bg_main"];
    
    _listView.backgroundView = imageView;


    _postView = [[UIView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:_postView];
    _postView.hidden = YES;
    
    _postCollectionView = [[PostCollectionView alloc] initWithFrame:_postView.bounds];
    _postCollectionView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"bg_main"]];
    _postCollectionView.movieData = _movieData;
    
    [_postView addSubview:_postCollectionView];
    
}

#pragma mark -创建右按钮
-(void)_creatButton{
    _rightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    _rightButton.frame = CGRectMake(0, 0, 49, 25);
    //设置按钮背景和图片
    [_rightButton setBackgroundImage:[UIImage imageNamed:@"exchange_bg_home"] forState:UIControlStateNormal];
    [_rightButton setImage:[UIImage imageNamed:@"list_home"] forState:UIControlStateNormal];
    [_rightButton setImage:[UIImage imageNamed:@"poster_home"] forState:UIControlStateSelected];
    [_rightButton setAdjustsImageWhenHighlighted:NO];
    
    //按钮添加方法
    [_rightButton addTarget:self
                     action:@selector(rightButtonAction:)
           forControlEvents:UIControlEventTouchUpInside];
    //将按钮添加到导航栏
    UIBarButtonItem *rightBtn = [[UIBarButtonItem alloc] initWithCustomView:_rightButton];
    self.navigationItem.rightBarButtonItem = rightBtn;
    
    
}

#pragma mark -右按钮方法
-(void)rightButtonAction:(UIButton *)sender{
    UIViewAnimationOptions options = sender.selected?
    UIViewAnimationOptionTransitionFlipFromRight:
    UIViewAnimationOptionTransitionFlipFromLeft;
    [self flipView:_rightButton options:options];
    [self flipView:self.view options:options];
    sender.selected = !sender.selected;
    _listView.hidden = !_listView.hidden;
    _postView.hidden = !_postView.hidden;
    BaseTabBarController *tab = (BaseTabBarController *)self.tabBarController;
    [tab setTabBarHidden:_listView.hidden];
    
    
}

#pragma mark -右按钮重复方法
-(void)flipView:(UIView *)view options:(UIViewAnimationOptions) options{
    [UIView transitionWithView:view
                      duration:.35 options:options
                    animations:^{
                    }
                    completion:nil];
    
    
}

#pragma mark -表视图协议方法实现
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return  _movieData.count;
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *identifire = @"MyCell";
    MyCell *cell = [tableView dequeueReusableCellWithIdentifier:identifire];
    
    if (cell == nil) {
        cell = [[[NSBundle mainBundle] loadNibNamed:@"MyCell" owner:nil options:nil]lastObject];
    }
    UIImageView *imageView = [[UIImageView alloc]init];
    imageView.image = [UIImage imageNamed:@"bg_main"];
    cell.backgroundView = imageView;  
    
    cell.movie = _movieData[indexPath.row];
    
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark -自定义表格高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 110;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
