//
//  MyCell.h
//  TimeMovie
//
//  Created by apple on 15/8/21.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@class Movie;
@interface MyCell : UITableViewCell

@property(nonatomic,strong)Movie *movie;

@end
