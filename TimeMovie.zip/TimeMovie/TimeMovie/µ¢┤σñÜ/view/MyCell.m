//
//  MyCell.m
//  TimeMovie
//
//  Created by apple on 15/8/21.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "MyCell.h"
#import "Movie.h"
#import "StarView.h"
@interface MyCell()

@property (weak, nonatomic) IBOutlet UIImageView *movieImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@property (weak, nonatomic) IBOutlet UILabel *yearLabel;
@property (weak, nonatomic) IBOutlet UILabel *ratingLabel;
@property (weak, nonatomic) IBOutlet UIView *ratingImage;

@end

@implementation MyCell



// 复写set方法
-(void)setMovie:(Movie *)movie{
    //[_view removeFromSuperview];
    _titleLabel.text = movie.titleC;
    _yearLabel.text = [NSString stringWithFormat:@"上映年份：%@",movie.year];
    _ratingLabel.text = [NSString stringWithFormat:@"%.1f",movie.rating];
    NSString *urlString = movie.images[@"small"];
    NSURL *url = [NSURL URLWithString:urlString];
    [_movieImageView sd_setImageWithURL:url];
    
    StarView *star = [[StarView alloc] initWithFrame:CGRectMake(0, 0, 120, 24)];
    star.rating = movie.rating;
    [_ratingImage addSubview:star];

}



- (void)awakeFromNib {
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
