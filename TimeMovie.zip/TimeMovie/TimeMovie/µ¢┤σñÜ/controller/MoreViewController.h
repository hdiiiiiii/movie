//
//  MoreViewController.h
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MoreViewController : UITableViewController

@end
