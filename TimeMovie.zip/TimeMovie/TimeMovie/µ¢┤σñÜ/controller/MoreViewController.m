//
//  MoreViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "MoreViewController.h"
#import "MoreCell.h"

@interface MoreViewController ()

@property (weak, nonatomic) IBOutlet UILabel *CacheLabel;

@end

@implementation MoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"更多";
    
    
    
}

-(void)viewDidAppear:(BOOL)animated{
    
    
    _CacheLabel.text = [NSString stringWithFormat:@"%.2fMB",
    [self countCacheFileSize]];
    
}

#pragma mark -清理缓存
-(void)clearCacheFile{
    //获取沙盒路径
    NSString *homePath = NSHomeDirectory();
    //NSLog(@"%@",homePath);
    NSArray *pathArray = @[@"/tmp/MediaCache/",@"/Library/Caches/com.hackemist.SDWebImageCache.default/",@"/Library/Caches/luohandi.TimeMovie/",@"/Library/Caches/luohandi.TimeMovie/fsCachedData/"];
    
    for (NSString *str in pathArray) {
        //拼接文件夹路径
        NSString *filePath = [NSString stringWithFormat:@"%@%@",homePath,str];
        
        NSFileManager *manager = [NSFileManager defaultManager];
        NSArray *fileNames = [manager subpathsOfDirectoryAtPath:filePath error:nil];
        for (NSString *fileName in fileNames) {
            //拼接文件路径
            NSString *subFilePath = [NSString stringWithFormat:@"%@%@",filePath,fileName];
            //删除缓存
            [manager removeItemAtPath:subFilePath error:nil];
        }
        
    }
    
    _CacheLabel.text = [NSString stringWithFormat:@"%.2fMB",[self countCacheFileSize]];
    
}
#pragma mark -表视图被选中时调用方法
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        //创建警告框
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"警告" message:@"是否清理缓存" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"是", nil];
        //显示警告框 默认隐藏
        [alert show];
    }
    
}
#pragma mark -警告框被选中时调用方法
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        [self clearCacheFile];
    }
    
}

#pragma mark -返回缓存文件总大小

-(CGFloat)countCacheFileSize{
    
    NSString *homePath = NSHomeDirectory();
    NSLog(@"%@",homePath);
    /* /tmp/MediaCache
       /Library/Caches/com.hackemist.SDWebImageCache.default
       /Library/Caches/luohandi.TimeMovie
      /Library/Caches/luohandi.TimeMovie/fsCachedData
    */
    NSArray *pathArray = @[@"/tmp/MediaCache/",@"/Library/Caches/com.hackemist.SDWebImageCache.default/",@"/Library/Caches/luohandi.TimeMovie/",@"/Library/Caches/luohandi.TimeMovie/fsCachedData/"];
    
    CGFloat fileSize = 0;
    
    for (NSString *str in pathArray) {
        NSString *filePath = [NSString stringWithFormat:@"%@%@",homePath,str];
        fileSize += [self getFileSize:filePath];
    }
    
    
    return fileSize;
}
#pragma mark - 返回单个文件夹中 缓存文件的大小
-(CGFloat)getFileSize:(NSString *)filePath{
    //文件管理器 单例
    NSFileManager *manager = [NSFileManager defaultManager];
    
    //数组 存储文件夹中所有的子文件及文件的名字
    NSArray *fileNames = [manager subpathsOfDirectoryAtPath:filePath error:nil];
    
    long long size = 0;
    for (NSString *fileName in fileNames) {
        NSString *subFilePath = [NSString stringWithFormat:@"%@%@",filePath,fileName];
        
        NSDictionary *dic = [manager attributesOfItemAtPath:subFilePath error:nil];
        NSNumber *sizeNumber = dic[NSFileSize];
        long long subFileSize = [sizeNumber longLongValue];
        
        size += subFileSize;
        
    }
    
    
    
    return size/1024.0/1024;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
