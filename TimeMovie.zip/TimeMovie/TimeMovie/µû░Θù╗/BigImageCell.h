//
//  BigImageCell.h
//  TimeMovie
//
//  Created by apple on 15/8/25.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BigImageCell : UICollectionViewCell

@property(nonatomic,strong)NSURL *imageUrl;
-(void)backImageZoomingScale;
@end
