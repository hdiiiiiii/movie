//
//  NewsViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "NewsViewController.h"
#import "MovieJSON.h"
#import "News.h"
#import "NewsCell.h"
#import "CollectionView.h"
#import "BaseTabBarController.h"
#import "WebViewController.h"

@interface NewsViewController ()
{
    NSMutableArray *_newsData;
    UIImageView *_imageView;
    
}
@end

@implementation NewsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"新闻";
    //载入数据
    [self loadData];

}
#pragma mark -载入数据
-(void)loadData{
    NSArray *array = [MovieJSON readJSONFile:@"news_list"];
    _newsData = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in array) {
        News *news = [[News alloc] initContentWithDic:dic];
        [_newsData addObject:news];
    }
    
    
}
#pragma mark -添加表视图

#pragma mark -实现协议方法
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _newsData.count;
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    News *news = _newsData[indexPath.row];
    if (indexPath.row == 0) {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TopNewsCell"];
        _imageView =(UIImageView *) [cell.contentView viewWithTag:100];
        UILabel *label = (UILabel *)[cell.contentView viewWithTag:101];
        [_imageView sd_setImageWithURL:[NSURL URLWithString:news.image]];
        label.text = news.title;
        return cell;
        
    }
    else
    {
        NewsCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NewsCell"];
        cell.titleLabel.text = news.title;
        cell.summaryLabel.text = news.summary;
        [cell.newsImageView sd_setImageWithURL:[NSURL URLWithString:news.image]];
        int type = [news.type intValue];
        if (type == 1) {
            cell.typeImageView.image = [UIImage imageNamed:@"sctpxw"];
        }
        else if (type == 2)
        {
            cell.typeImageView.image = [UIImage imageNamed:@"scspxw"];
        }
        return cell;
    }
    
    
}
#pragma mark -设置单元格高度
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row == 0) {
        return 150;
    }
    else{
        return 70;
    }
    
}

#pragma mark -选中表视图
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    News *news = _newsData[indexPath.row];
    int type = [news.type intValue];
    if (type == 1) {
        CollectionView *Cview = [[CollectionView alloc] init];
        
        Cview.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:Cview animated:YES];
    }
    else if([news.type isEqualToNumber:@0]){
        WebViewController *web = [[WebViewController alloc] init];
        [self.navigationController pushViewController:web animated:YES];
        web.hidesBottomBarWhenPushed = YES;
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark -设置滑动放大
- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat yOffSet = scrollView.contentOffset.y+64;
    if (yOffSet <0) {
        CGFloat oldImageHeight = 150;
        CGFloat newImagHeight = 150-yOffSet;
        
        CGFloat scale = newImagHeight/oldImageHeight;
        
        CGAffineTransform transfrom = CGAffineTransformMakeScale(scale, scale);
        
        _imageView.transform = transfrom;
        
        _imageView.top = yOffSet;
    }

    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
