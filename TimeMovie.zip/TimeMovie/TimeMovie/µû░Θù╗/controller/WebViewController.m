//
//  WebViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/31.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "WebViewController.h"

@interface WebViewController ()

@end

@implementation WebViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"电影详情";
    
    UIWebView *webView = [[UIWebView alloc] initWithFrame:self.view.bounds];
    [self.view addSubview:webView];
    
    //获取路径
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"news.html" ofType:nil];
    NSString *htmlString = [NSString stringWithContentsOfFile:filePath encoding:NSUTF8StringEncoding error:nil];
    
    //NSString *qweqw = [NSString stringWithContentsOfURL:[NSURL URLWithString:@"http://jingxuan.guokr.com/pick/v2/16314/"] encoding:NSUTF8StringEncoding error:nil];
    
    NSDictionary *dic = [MovieJSON readJSONFile:@"news_detail"];
    NSString *title = dic[@"title"];
    NSString *content = dic[@"content"];
    NSString *time = dic[@"time"];
    //NSString *source = dic[@"source"];
    
    htmlString = [NSString stringWithFormat:htmlString,title,content,time];
    
    [webView loadHTMLString:htmlString baseURL:nil];
    webView.scalesPageToFit = YES;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
