//
//  News.m
//  TimeMovie
//
//  Created by apple on 15/8/22.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "News.h"

@implementation News

- (NSDictionary *)attributeMapDictionary:(NSDictionary *)jsonDic {
    
    NSMutableDictionary *mapDic = [NSMutableDictionary dictionary];
    
    for (id key in jsonDic) {
        [mapDic setObject:key forKey:key];
    }
    
    [mapDic setObject:@"NewsID" forKey:@"id"];
    return mapDic;
}

@end
