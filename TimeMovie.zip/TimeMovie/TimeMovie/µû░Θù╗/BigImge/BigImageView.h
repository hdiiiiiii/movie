//
//  BigImageView.h
//  TimeMovie
//
//  Created by apple on 15/8/25.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "BaseViewController.h"

@interface BigImageView : BaseViewController

@property(nonatomic,strong)NSArray *imageData;
@property(nonatomic,strong)NSIndexPath *indexPath;

@end
