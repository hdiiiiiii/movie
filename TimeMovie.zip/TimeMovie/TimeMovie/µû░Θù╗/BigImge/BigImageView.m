//
//  BigImageView.m
//  TimeMovie
//
//  Created by apple on 15/8/25.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "BigImageView.h"
#import "BigImageCell.h"
@interface BigImageView ()<UICollectionViewDataSource,UICollectionViewDelegate>
{
    UICollectionView *_imageCollectionView;
    BOOL _isHiddenNav;
    
}
@end

@implementation BigImageView

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"图片";
    self.view.backgroundColor = [UIColor blackColor];
    [self _creatView];
    [_imageCollectionView scrollToItemAtIndexPath:_indexPath atScrollPosition:UICollectionViewScrollPositionLeft animated:NO];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(hiddenNav) name:@"hiddenNav" object:nil];
    
    
}
#pragma mark -移除通知
-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}

#pragma mark -通知方法
-(void)hiddenNav{
    _isHiddenNav = !_isHiddenNav;
    if (_isHiddenNav) {
        [self.navigationController setNavigationBarHidden:YES animated:YES];
        UIApplication *app = [UIApplication sharedApplication];
        [app setStatusBarHidden:YES withAnimation:UIStatusBarAnimationSlide];
        
    }
    else{
        [self.navigationController setNavigationBarHidden:NO animated:YES];
        UIApplication *app = [UIApplication sharedApplication];
        [app setStatusBarHidden:NO withAnimation:UIStatusBarAnimationSlide];
    }
    
    
}


-(void)_creatView{
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    layout.itemSize = CGSizeMake(kScreenWidth, kScreenHeight- 64);
    layout.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    layout.sectionInset = UIEdgeInsetsMake(-15, 0, 0, 0);
    
    _imageCollectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 64, kScreenWidth+10, kScreenHeight - 64) collectionViewLayout:layout];
    _imageCollectionView.dataSource = self;
    _imageCollectionView.delegate = self;
    _imageCollectionView.backgroundColor = [UIColor blackColor];
    
    [self.view addSubview:_imageCollectionView];
    
    _imageCollectionView.showsHorizontalScrollIndicator = NO;
    _imageCollectionView.pagingEnabled = YES;
    
    [_imageCollectionView registerClass:[BigImageCell class] forCellWithReuseIdentifier:@"BigImageCell"];
    
    
    
}
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _imageData.count;
    
    
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    BigImageCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"BigImageCell" forIndexPath:indexPath];
    
    cell.backgroundColor = [UIColor blackColor];
    cell.imageUrl = _imageData[indexPath.item];
    return cell;
    
    
}



#pragma mark -换页时还原图片
-(void)collectionView:(UICollectionView *)collectionView didEndDisplayingCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath{
    BigImageCell *big = (BigImageCell *)cell;
    [big backImageZoomingScale];
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
