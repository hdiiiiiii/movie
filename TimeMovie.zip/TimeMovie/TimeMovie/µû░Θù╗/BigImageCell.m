//
//  BigImageCell.m
//  TimeMovie
//
//  Created by apple on 15/8/25.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "BigImageCell.h"

@interface BigImageCell()<UIScrollViewDelegate>
{
    
    UIScrollView *_scrollView;
    UIImageView *_imageView;
    NSTimer *_timer;
}

@end


@implementation BigImageCell


-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        [self _createViews];
    }
    return self;
}


-(void)_createViews{
    _scrollView = [[UIScrollView alloc] initWithFrame:self.bounds];
    _scrollView.contentSize = self.frame.size;
    
    //设置放大倍数
    _scrollView.maximumZoomScale = 3;
    _scrollView.minimumZoomScale = .3;
    
    _scrollView.delegate = self;
    [self.contentView addSubview:_scrollView];
    
    //创建图片视图
    _imageView = [[UIImageView alloc] initWithFrame:self.bounds];
    _imageView.image = [UIImage imageNamed:@"icon"];
    _imageView.contentMode = UIViewContentModeScaleAspectFit;
    [_scrollView addSubview:_imageView];
    //设置手势
    UITapGestureRecognizer *oneTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(oneTapAction)];
    oneTap.numberOfTapsRequired = 1;
    oneTap.numberOfTouchesRequired = 1;
    [_imageView addGestureRecognizer:oneTap];
    
    UITapGestureRecognizer *twoTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(twoTapAction)];
    twoTap.numberOfTapsRequired = 2;
    twoTap.numberOfTouchesRequired = 1;
    [_imageView addGestureRecognizer:twoTap];
    _imageView.userInteractionEnabled = YES;
    
    
    
    
}
-(void)oneTapAction{
    _timer = [NSTimer scheduledTimerWithTimeInterval:0.5
                                              target:self
                                            selector:@selector(oneAction)
                                            userInfo:nil
                                             repeats:NO];
    
    
}
-(void)oneAction{
    [[NSNotificationCenter defaultCenter] postNotificationName:@"hiddenNav" object:nil];
    
}

-(void)twoTapAction{
    [_timer invalidate];
    if (_scrollView.zoomScale >1) {
        [_scrollView setZoomScale:1 animated:YES];
    }
    else{
        
        [_scrollView setZoomScale:2 animated:YES];
    }
    
}

-(UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return _imageView;
    
}

-(void)setImageUrl:(NSURL *)imageUrl{
    _imageUrl = imageUrl;
    [_imageView sd_setImageWithURL:_imageUrl];
    
}

-(void)backImageZoomingScale{
    
    [_scrollView setZoomScale:1];
}
@end
