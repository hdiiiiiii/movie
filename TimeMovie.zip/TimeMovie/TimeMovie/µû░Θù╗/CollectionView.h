//
//  CollectionView.h
//  TimeMovie
//
//  Created by apple on 15/8/23.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "BaseViewController.h"

@interface CollectionView : BaseViewController

@end
