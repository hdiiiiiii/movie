//
//  CollectionView.m
//  TimeMovie
//
//  Created by apple on 15/8/23.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "CollectionView.h"
#import "BigImageView.h"

@interface CollectionView ()<UICollectionViewDelegate,UICollectionViewDataSource>
{
    NSMutableArray *_imageData;
}

@end

@implementation CollectionView

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"图片";
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 150, 40)];
    label.text = @"图片新闻";
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    label.font = [UIFont systemFontOfSize:20 weight:1];
    self.navigationItem.titleView = label;
    
    
    //读取图片网址
    [self _loadData];
    
    //布局
    UICollectionViewFlowLayout *flowLayou = [[UICollectionViewFlowLayout alloc] init];
    flowLayou.minimumInteritemSpacing = 10;
    flowLayou.minimumLineSpacing = 10;
    CGFloat itemSize = (kScreenWidth - 10*5)/4;
    flowLayou.itemSize = CGSizeMake(itemSize, itemSize);
    flowLayou.sectionInset = UIEdgeInsetsMake(20, 10, 10, 10);
    flowLayou.scrollDirection = UICollectionViewScrollDirectionVertical;
    
    //创建
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:self.view.bounds collectionViewLayout:flowLayou];
    [self.view addSubview:collectionView];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    
    [collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    
    
    
}
-(void)_loadData{
    NSArray *array = [MovieJSON readJSONFile:@"image_list"];
    _imageData = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in array) {
        NSString *image = dic[@"image"];
        [_imageData addObject:image];
    }
    
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return _imageData.count;
    
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
    UIImageView *imageView = [[UIImageView alloc] init];
    [imageView sd_setImageWithURL:[NSURL URLWithString:_imageData[indexPath.row]]placeholderImage:[UIImage imageNamed:@"icon"] ];
    
    cell.backgroundView = imageView;
    //视图边框
    //设置边框颜色
    cell.layer.borderColor = [UIColor purpleColor].CGColor;
    //边框宽度
    cell.layer.borderWidth = 2;
    //视图的圆角
    //cell.layer.cornerRadius = cell.width/2;
    cell.layer.cornerRadius = 8;
    cell.layer.masksToBounds = YES;
    
    return cell;
}
#pragma mark -进入选中图片
-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    BigImageView *big = [[BigImageView alloc] init];
    
    big.imageData = _imageData;
    big.hidesBottomBarWhenPushed = YES;
    
    big.indexPath = indexPath;
    
    [self.navigationController pushViewController:big animated:YES];
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
