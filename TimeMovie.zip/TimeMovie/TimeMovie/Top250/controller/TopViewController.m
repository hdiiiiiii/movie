//
//  TopViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/19.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "TopViewController.h"
#import "Movie.h"
#import "topCell.h"
#import "DetailViewController.h"

@interface TopViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
{
    NSMutableArray *_topData;
}
@end

@implementation TopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Top250";
    //读取数据
    [self _loadData];
    
    
    
    
}
#pragma mark -读取数据
-(void)_loadData{
    NSDictionary *dic = [MovieJSON readJSONFile:@"top250"];
    _topData = [[NSMutableArray alloc] init];
    
    for (NSDictionary *d in dic[@"subjects"]) {
        Movie *movie = [[Movie alloc] initWithContentsOfDictionary:d];
        [_topData addObject:movie];
    }
    
    
    
}

#pragma mark - 协议方法
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    return _topData.count;
    
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    topCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"topCell" forIndexPath:indexPath];
    
    cell.movie = _topData[indexPath.item];
    
    return cell;
}


#pragma mark -设置单元格宽高
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    CGFloat cellWidth = (kScreenWidth - 10*4)/3;
    CGFloat cellHeight = cellWidth*1.3;
    return CGSizeMake(cellWidth, cellHeight);
    
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    DetailViewController *detailView = [storyBoard instantiateViewControllerWithIdentifier:@"detail"];
    detailView.hidesBottomBarWhenPushed = YES;
    
    [self.navigationController pushViewController:detailView animated:YES];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
