//
//  DetailViewController.m
//  TimeMovie
//
//  Created by apple on 15/8/28.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "DetailViewController.h"
#import "DetailViewCell.h"
#import "DetailHeadView.h"
#import "Comment.h"

@interface DetailViewController ()<UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray *_commentData;
}


@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation DetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"电影详情";
    
    [self _loadData];
    
    DetailHeadView *detailHead = [[[NSBundle mainBundle] loadNibNamed:@"DetailHeadView" owner:nil options:nil] lastObject];
    _tableView.tableHeaderView = detailHead;
    detailHead.nav = self.navigationController;
    
    
    
}


-(void)_loadData{
    NSDictionary *dic1 = [MovieJSON readJSONFile:@"movie_comment"];
    NSArray *array = dic1[@"list"];
    _commentData = [[NSMutableArray alloc] init];
    for (NSDictionary *dic in array) {
        Comment *c = [[Comment alloc] initContentWithDic:dic];
        [_commentData addObject:c];
        
    }
    
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _commentData.count ;
    
    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    DetailViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"detailCell"];
    cell.comment = _commentData[indexPath.row];
    return cell;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    Comment *comment = _commentData[indexPath.row];
    NSString *str = comment.content;
    
    if (comment.isShow) {
        CGSize maxSize = CGSizeMake(229, CGFLOAT_MAX);
        NSDictionary *dic = @{NSFontAttributeName :[UIFont systemFontOfSize:17]};
        CGRect rec = [str boundingRectWithSize:maxSize
                                       options:NSStringDrawingUsesLineFragmentOrigin
                                    attributes:dic
                                       context:nil];
        
        return rec.size.height+40;
        
    }
    else
    {
    return 60;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    Comment *comment  = _commentData[indexPath.row];
    comment.isShow = !comment.isShow;
    
    [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
