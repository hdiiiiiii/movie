//
//  Comment.m
//  TimeMovie
//
//  Created by apple on 15/8/28.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "Comment.h"

@implementation Comment

@end
