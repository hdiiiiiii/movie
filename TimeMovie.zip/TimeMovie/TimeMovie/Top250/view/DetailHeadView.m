//
//  DetailHeadView.m
//  TimeMovie
//
//  Created by apple on 15/8/28.
//  Copyright (c) 2015年 apple. All rights reserved.


 

#import "DetailHeadView.h"
#import "HeadCollectionCell.h"
#import <MediaPlayer/MediaPlayer.h>
@interface DetailHeadView ()<UICollectionViewDataSource,UICollectionViewDelegate>
{
    
    NSDictionary *_dic;
}


@end

@implementation DetailHeadView
-(void)awakeFromNib{
    
    //读取数据
    [self _loadData];
    
    [self _creatView];
    
}
/*
 @property (weak, nonatomic) IBOutlet UIImageView *movieImageView;
 @property (weak, nonatomic) IBOutlet UILabel *titleCLabel;
 @property (weak, nonatomic) IBOutlet UILabel *directionLabel;
 
 @property (weak, nonatomic) IBOutlet UILabel *actorLabel;
 @property (weak, nonatomic) IBOutlet UILabel *typeLabel;
 @property (weak, nonatomic) IBOutlet UILabel *yearLabel;
 */

-(void)_loadData{
    _dic = [MovieJSON readJSONFile:@"movie_detail"];
    NSURL *url = [NSURL URLWithString:_dic[@"image"]];
    [_movieImageView sd_setImageWithURL:url];
    _titleCLabel.text = _dic[@"titleCn"];
    NSArray *direcArr = _dic[@"directors"];
    _directionLabel.text = direcArr[0];
    NSArray *actArr = _dic[@"actors"];
    
    NSString *actStr = @"主演：";
    for (int i = 0; i < actArr.count; i++) {
        actStr = [NSString stringWithFormat:@"%@%@",actStr,actArr[i]];
    }
    _actorLabel.text = actStr;
    NSArray *typeArr = _dic[@"type"];
    
    NSString *typeStr = @"类型：";
    for (int i = 0; i<typeArr.count; i++) {
        typeStr = [NSString stringWithFormat:@"%@%@",typeStr,typeArr[i]];
    }
    _typeLabel.text = typeStr;
    
    NSDictionary *year = _dic[@"release"];
    NSString *yearStr = [NSString stringWithFormat:@"%@ %@",year[@"location"],year[@"date"]];
    _yearLabel.text = yearStr;
    
    
}
-(void)_creatView{
    //布局
    UICollectionViewFlowLayout *flowLayou = [[UICollectionViewFlowLayout alloc] init];
    flowLayou.minimumInteritemSpacing = 10;
    flowLayou.minimumLineSpacing = 10;
    flowLayou.itemSize = CGSizeMake((kScreenWidth-20-30)/4, 60);
    flowLayou.sectionInset = UIEdgeInsetsMake(0, 5, 0, 5);
    flowLayou.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    
    //创建
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(10, 120, kScreenWidth-20, 70) collectionViewLayout:flowLayou];
    [self addSubview:collectionView];
    collectionView.dataSource = self;
    collectionView.delegate = self;
    collectionView.layer.cornerRadius = 7;
    collectionView.layer.borderColor = [UIColor whiteColor].CGColor;
    collectionView.layer.borderWidth = 2;
    collectionView.backgroundColor = [UIColor blackColor];
    
    [collectionView registerClass:[HeadCollectionCell class] forCellWithReuseIdentifier:@"Headcell"];
    
    
    
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    NSArray *array = _dic[@"images"];
    return array.count;
    
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    HeadCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"Headcell" forIndexPath:indexPath];
    NSArray *array = _dic[@"images"];
    NSURL *url = [NSURL URLWithString:array[indexPath.item]];
    cell.imageUrl = url;
    return cell;
    
    
}
- (IBAction)playMoview:(UIButton *)sender {
    //http://vf1.mtime.cn/Video/2012/04/23/mp4/120423212602431929.mp4
    MPMoviePlayerViewController *movie = [[MPMoviePlayerViewController alloc] initWithContentURL:[NSURL URLWithString:@"http://vf1.mtime.cn/Video/2012/04/23/mp4/120423212602431929.mp4"]];
    
    [self.nav pushViewController:movie animated:YES];
}


@end
