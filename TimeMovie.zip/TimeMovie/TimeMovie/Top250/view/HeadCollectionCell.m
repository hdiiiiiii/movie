//
//  HeadCollectionCell.m
//  TimeMovie
//
//  Created by apple on 15/8/29.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "HeadCollectionCell.h"

@implementation HeadCollectionCell

-(id)initWithFrame:(CGRect)frame{
    self= [super initWithFrame:frame];
    if (self) {
        [self _creatViews];
    }
    return self;
}

-(void)_creatViews{
    
    _imageView = [[UIImageView alloc] initWithFrame:self.bounds];
    [self.contentView addSubview:_imageView];
    _imageView.layer.cornerRadius = 10;
    _imageView.layer.borderWidth = 3;
    _imageView.layer.borderColor = [UIColor orangeColor].CGColor;
    _imageView.layer.masksToBounds = YES;
    
}
-(void)setImageUrl:(NSURL *)imageUrl{
    
    _imageUrl = imageUrl;
    
    [_imageView sd_setImageWithURL:_imageUrl placeholderImage:[UIImage imageNamed:@"icon"]];
}
@end
