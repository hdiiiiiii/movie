//
//  DetailViewCell.m
//  TimeMovie
//
//  Created by apple on 15/8/28.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "DetailViewCell.h"

@implementation DetailViewCell

-(void)setComment:(Comment *)comment
{
    _comment = comment;
    self.commentLabel.text = _comment.content;
    self.uesrNameLabel.text = _comment.nickname;
    NSURL *url = [NSURL URLWithString:_comment.userImage];
    [_userImageView sd_setImageWithURL:url];
    self.ratingLabel.text = _comment.rating;
    _bgView.layer.cornerRadius = 5;
    _bgView.layer.borderColor = [UIColor whiteColor].CGColor;
    _bgView.layer.borderWidth = 3;
    
}


- (void)awakeFromNib {
    // Initialization code
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
