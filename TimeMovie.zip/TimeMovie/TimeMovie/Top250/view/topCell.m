//
//  topCell.m
//  TimeMovie
//
//  Created by apple on 15/8/24.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "topCell.h"
#import "StarView.h"
@implementation topCell
-(void)setMovie:(Movie *)movie{
    _movie = movie;
    
    [_movieImageView sd_setImageWithURL:[NSURL URLWithString:_movie.images[@"small"]] placeholderImage:[UIImage imageNamed:@"icon"]];
    _titleLabel.text = _movie.titleC;
    _ratingLabel.text = [NSString stringWithFormat:@"%.1f",_movie.rating];    
    StarView *starView = [[StarView alloc] initWithFrame:_view.bounds];
    
    
    starView.rating = _movie.rating;
    [_view addSubview:starView];
    
    
}
@end
