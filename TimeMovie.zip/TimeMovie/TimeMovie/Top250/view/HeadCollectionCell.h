//
//  HeadCollectionCell.h
//  TimeMovie
//
//  Created by apple on 15/8/29.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HeadCollectionCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView *imageView;

@property(nonatomic,strong)NSURL *imageUrl;
@end
